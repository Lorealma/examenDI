package com.example.examendi.controladores;

import com.example.examendi.modelos.Cliente;
import com.example.examendi.modelos.Entrada;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Label info;
    @FXML
    private TextField lbl_matricula;
    @FXML
    private Label lbl_coste;
    @FXML
    private RadioButton rb_standard;
    @FXML
    private ChoiceBox<Cliente> cb_cliente;
    @FXML
    private DatePicker dp_entrada;
    @FXML
    private DatePicker dp_salida;
    @FXML
    private Button btn_anadir;
    @FXML
    private Button btn_salir;
    @FXML
    private TableView<Entrada> tv_tabla;
    @FXML
    private TableColumn<Entrada, String> cMatricula;
    @FXML
    private TableColumn<Entrada, String> cModelo;
    @FXML
    private TableColumn<Entrada, Date> cFechaEntrega;
    @FXML
    private TableColumn<Entrada, Date> cFechaSalida;
    @FXML
    private TableColumn<Entrada, Cliente> cCliente;
    @FXML
    private TableColumn<Entrada, String> cTarifa;
    @FXML
    private TableColumn<Entrada, String> cCoste;
    @FXML
    private RadioButton rb_oferta;
    @FXML
    private RadioButton rb_largaDuracion;
    @FXML
    private ComboBox<String> cb_modelo;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        ObservableList<String> elementos = FXCollections.observableArrayList();
        elementos.addAll("Modelo1", "Modelo2", "Modelo3");
        cb_modelo.setItems(elementos);

        cb_modelo.getSelectionModel().selectFirst();

        ObservableList<Cliente> listaClientes = FXCollections.observableArrayList();
        listaClientes.addAll();
        cb_cliente.setItems(listaClientes);

        cb_cliente.getSelectionModel().selectFirst();


        ArrayList<Entrada> listaEntrada = new ArrayList<>();

        listaEntrada.add(new Entrada());
        listaEntrada.add(new Entrada());
        listaEntrada.add(new Entrada());
        listaEntrada.add(new Entrada());
        listaEntrada.add(new Entrada());
        listaEntrada.add(new Entrada());

        ToggleGroup tb = new ToggleGroup();

        this.rb_standard.setToggleGroup(tb);
        this.rb_oferta.setToggleGroup(tb);
        this.rb_largaDuracion.setToggleGroup(tb);



    }

    @FXML
    public void anadir(ActionEvent actionEvent) {


       /*
            String matricula = this.cMatricula.setText();
            String modelo = this.cModelo.setText();
            Cliente cliente = this.cModelo.setText();
            String tarifa = this.cTarifa.setText();
            Date fechaEntrada = this.cFechaEntrega.setText();
            Date fechaSalida = this.cFechaSalida.setText();
            String coste = this.cCoste.setText();


            Entrada en = new Entrada(matricula, modelo, cliente,tarifa,fechaEntrada,fechaSalida);


            try {

            }catch (NumberFormatException e){

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setContentText("Ningún campo puede quedar vacio.");
                alert.setGraphic(null);
                alert.showAndWait();

         }*/
    }



    @FXML
    public void salir(ActionEvent actionEvent) {

        System.exit(0);

    }


}