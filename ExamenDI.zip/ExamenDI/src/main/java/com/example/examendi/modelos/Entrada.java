package com.example.examendi.modelos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class Entrada {


    private String matricula;
    private String modeloCoche;
    private Cliente cliente;
    private String tipoTarifa;
    private Date fechaEntrada;
    private Date fechaSalida;
    private String costeTotal;


    public Entrada(String matricula, String modeloCoche, Cliente cliente, String tipoTarifa, Date fechaEntrada, Date fechaSalida) {
        this.matricula = matricula;
        this.modeloCoche = modeloCoche;
        this.cliente = cliente;
        this.tipoTarifa = tipoTarifa;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.costeTotal = costeTotal;
    }
}
