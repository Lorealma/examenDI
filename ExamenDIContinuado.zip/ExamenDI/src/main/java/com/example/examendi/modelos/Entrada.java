package com.example.examendi.modelos;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
public class Entrada {


    private String matricula;
    private String modeloCoche;
    //private Cliente cliente;
    private String cliente; //No consigo poner valores en la tabla teniéndolo como objeto por lo que lo he dejado como String
    private String tipoTarifa;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;
    private String costeTotal;


    public Entrada(String matricula, String modeloCoche, String cliente, String tipoTarifa, LocalDate fechaEntrada, LocalDate fechaSalida, String costeTotal) {
        this.matricula = matricula;
        this.modeloCoche = modeloCoche;
        this.cliente = cliente;
        this.tipoTarifa = tipoTarifa;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.costeTotal = costeTotal;
    }




    public void setFechaEntrada(LocalDate value) {
    }
}
