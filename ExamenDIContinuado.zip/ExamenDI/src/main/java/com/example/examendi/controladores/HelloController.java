package com.example.examendi.controladores;

import com.example.examendi.modelos.Cliente;
import com.example.examendi.modelos.Entrada;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Label info;
    @FXML
    private TextField lbl_matricula;
    @FXML
    private RadioButton rb_standard;
    @FXML
    private ChoiceBox<String> cb_cliente;
    @FXML
    private DatePicker dp_entrada;
    @FXML
    private DatePicker dp_salida;
    @FXML
    private Button btn_anadir;
    @FXML
    private Button btn_salir;
    @FXML
    private TableView<Entrada> tv_tabla;
    @FXML
    private TableColumn<Entrada, String> cMatricula;
    @FXML
    private TableColumn<Entrada, String> cModelo;
    @FXML
    private TableColumn<Entrada, String> cFechaSalida;
    @FXML
    private TableColumn<Entrada, String> cFechaEntrada;
    @FXML
    private TableColumn<Entrada, String> cCliente;
    @FXML
    private TableColumn<Entrada, String> cTarifa;
    @FXML
    private TableColumn<Entrada, String> cCoste;
    @FXML
    private RadioButton rb_oferta;
    @FXML
    private RadioButton rb_largaDuracion;
    @FXML
    private ComboBox<String> cb_modelo;
    @FXML
    private Label tf_coste;

    private ObservableList<Entrada> entrada;

    ToggleGroup tb = new ToggleGroup();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        ObservableList<String> elementos = FXCollections.observableArrayList();
        elementos.addAll("Hyundai", "Mitsubishi", "Chevrolet");
        cb_modelo.setItems(elementos);

        cb_modelo.getSelectionModel().selectFirst();

        ObservableList<String> listaClientes = FXCollections.observableArrayList();
        listaClientes.addAll("Marina","Carlos","Oscar");
        cb_cliente.setItems(listaClientes);

        cb_cliente.getSelectionModel().selectFirst();

        //Algunos ejemplos para que salgan en la tabla al iniciar

        tv_tabla.getItems().add(new Entrada("4563SCC", "BMW", "Alejandro","Oferta",
                LocalDate.of(2019,10,1), LocalDate.of(2020,9,5),"20.000€"));
        tv_tabla.getItems().add(new Entrada("9876MNN", "Audi", "Inés","Standard",
                LocalDate.of(2015,1,18), LocalDate.of(2020,5,22),"40.000€"));



        entrada = FXCollections.observableArrayList();

        this.cMatricula.setCellValueFactory(new PropertyValueFactory<>("matricula"));
        this.cModelo.setCellValueFactory(new PropertyValueFactory<>("modeloCoche"));
        this.cCliente.setCellValueFactory(new PropertyValueFactory<>("cliente"));
        this.cTarifa.setCellValueFactory(new PropertyValueFactory<>("tipoTarifa"));
        this.cFechaEntrada.setCellValueFactory(new PropertyValueFactory<>("fechaEntrada"));
        this.cFechaSalida.setCellValueFactory(new PropertyValueFactory<>("fechaSalida"));
        this.cCoste.setCellValueFactory(new PropertyValueFactory<>("coste"));



        cMatricula.setCellValueFactory((fila)->{
            String matricula = fila.getValue().getMatricula();
            return new SimpleStringProperty(matricula);
        });
        cModelo.setCellValueFactory((fila)->{
            String modeloCoche = fila.getValue().getModeloCoche();
            return new SimpleStringProperty(modeloCoche);
        });
        cCliente.setCellValueFactory((fila)->{
            String cliente = fila.getValue().getCliente();
            return new SimpleStringProperty(cliente);
        });
        cTarifa.setCellValueFactory((fila)->{
            String tipoTarifa = fila.getValue().getTipoTarifa();
            return new SimpleStringProperty(tipoTarifa);
        });
        cFechaEntrada.setCellValueFactory((fila)->{
            String fechaEntrada = String.valueOf(fila.getValue().getFechaEntrada());
            return new SimpleStringProperty(fechaEntrada);
        });
        cFechaSalida.setCellValueFactory((fila)->{
            String fechaSalida = String.valueOf(fila.getValue().getFechaSalida());
            return new SimpleStringProperty(fechaSalida);
        });
        cCoste.setCellValueFactory((fila)->{
            String costeTotal = fila.getValue().getCosteTotal();
            return new SimpleStringProperty(costeTotal);
        });



        this.rb_standard.setToggleGroup(tb);
        this.rb_oferta.setToggleGroup(tb);
        this.rb_largaDuracion.setToggleGroup(tb);



    }

    @FXML
    public void anadir(ActionEvent actionEvent) {

        Entrada ent = new Entrada();

        if(lbl_matricula.getText().isEmpty() ||
                (cb_modelo.getSelectionModel().getSelectedItem() == null) ||
                (tb.getSelectedToggle().toString() == null) ||
                (dp_entrada.getValue() == null) ||
                (dp_salida.getValue() == null) ||
                tf_coste.getText().isEmpty())

        {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Ningún campo puede quedar vacio.");
            alert.setGraphic(null);
            alert.showAndWait();

        }else{


            ent.setMatricula(lbl_matricula.getText());
            ent.setModeloCoche(String.valueOf(cb_modelo.getSelectionModel().getSelectedItem()));
            /*String c = cb_cliente.getSelectionModel().getSelectedItem();
            Cliente cliente = new Cliente(c);      //Esta parte la tenía hecha cuando estaba trabajando con cliente como objeto
            ent.setCliente(cliente);*/             //pero no conseguia darle valores
            ent.setCliente(String.valueOf(cb_modelo.getSelectionModel().getSelectedItem()));
            if(rb_standard.isSelected()){
                ent.setTipoTarifa("Standard");
            } else if (rb_oferta.isSelected()) {
                ent.setTipoTarifa("Oferta");
            }else if(rb_largaDuracion.isSelected()){
                ent.setTipoTarifa("Larga duración");
            }
            ent.setFechaEntrada(dp_entrada.getValue());
            ent.setFechaSalida(dp_salida.getValue());
            if(rb_standard.isSelected()){
                ent.setCosteTotal("8€");
            } else if (rb_oferta.isSelected()) {
                ent.setCosteTotal("6€");
            }else if(rb_largaDuracion.isSelected()){
                ent.setCosteTotal("2€");
            }



            entrada.add(ent);
            tv_tabla.setItems(entrada);


        }

        //Como en el enunciado pone que todos los campos deben reiniciarse cuando
        //añadamos información a la tabla y no estaba segura si eran todos o solo
        //los campos a los que NO hemos dado un valor por defecto, he reiniciado todos
        //menos el RadioButton ya que el RadioButton lo he puesto por defecto seleccionado
        //desde el SceneBuilder

        lbl_matricula.setText("");
        cb_modelo.setValue(null);
        cb_cliente.setValue(null);
        dp_entrada.setValue(null);
        dp_salida.setValue(null);




        /*String matricula = this.lbl_matricula.getText();
        String modeloCoche = this.cb_modelo.getSelectionModel().getSelectedItem();
        String cliente = this.cb_cliente.getSelectionModel().getSelectedItem();
        String tipoTarifa = this.tb.getSelectedToggle().toString();
        LocalDate fechaEntrada = this.dp_entrada.getValue();
        LocalDate fechaSalida = this.dp_salida.getValue();
        String costeTotal = this.tf_coste.getText();

        Entrada ent = new Entrada(matricula, modeloCoche, cliente, tipoTarifa, fechaEntrada, fechaSalida, costeTotal);
        */


    }


    @FXML
    public void salir(ActionEvent actionEvent) {

        System.exit(0);

    }


    @FXML
    public void clickLabel(Event event) {  

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Información alumno");
            alert.setContentText("Nombre: Lorena Alemán Marín | Ciclo: 2ºDAM");
            alert.setGraphic(null);
            alert.showAndWait();


    }
}