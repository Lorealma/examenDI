module com.example.examendi {
    requires javafx.controls;
    requires javafx.fxml;
    requires lombok;


    opens com.example.examendi to javafx.fxml;
    exports com.example.examendi;
    exports com.example.examendi.controladores;
    opens com.example.examendi.controladores to javafx.fxml;
}